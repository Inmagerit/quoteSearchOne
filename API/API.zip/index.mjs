import { MongoClient } from 'mongodb';

const uri = "mongodb+srv://admin:<password>@bookscluster.vqnq5.mongodb.net/?retryWrites=true&w=majority&appName=booksCluster";
let client;
let clientPromise;

// Inicia una única instancia de MongoClient (caché)
if (!clientPromise) {
    client = new MongoClient(uri);
    clientPromise = client.connect(); // Almacena la promesa de conexión para reutilizarla
}

// Exporta el handler de Lambda
export const handler = async (event) => {
    const query = event.queryStringParameters?.query || '';

    try {
        // Espera la conexión al cliente MongoDB
        await clientPromise;
        
        const database = client.db("booksDB");
        const collection = database.collection("booksCOLL");

        // Define el pipeline de agregación para la consulta autocomplete
        const agg = [
            {
                $search: {
                    index: "bookSearchAutocomplete",
                    autocomplete: {
                        query: query,
                        path: "content" // Cambia esto según tu colección
                    }
                }
            },
            { $limit: 20 },
            { $project: { _id: 0, title: 1, content: 1, author: 1 } }
        ];

        const results = await collection.aggregate(agg).toArray();

        // Retorna los resultados con los encabezados de CORS
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*', 
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS', 
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            body: JSON.stringify({ books: results })
        };
    } catch (error) {
        console.error("Error al realizar la búsqueda:", error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*', 
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            body: JSON.stringify({ error: 'Error al realizar la búsqueda' })
        };
    }
};
